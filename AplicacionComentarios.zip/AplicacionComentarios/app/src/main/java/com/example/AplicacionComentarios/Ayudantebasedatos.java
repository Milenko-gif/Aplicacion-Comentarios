package com.example.AplicacionComentarios;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Ayudantebasedatos extends SQLiteOpenHelper {

    static final String DB_NAME="Emp";
    static final int DB_VER=3;
    // Nombre Tabla
    static String TABLE_NAME="userdata";
    //Nombre Columna
    static String UID="uid";
    static String PASSWORD="pass";

   // Ayudantebasedatos(Context ct) {
       // super(ct, "Emp.db", null, 3);


    //}
   Ayudantebasedatos(Context ct) { super(ct, DB_NAME, null, DB_VER); // Crear base de datos
   }
    @Override
    public void onCreate(SQLiteDatabase db) {
        //crear tablas //

        String createstr="create table "+TABLE_NAME+"("+ UID +" text not null ," + PASSWORD +" text not null"+")";
        db.execSQL(createstr);
    }

    //método definido por el usuario para insertar datos en la tabla
    public void  addData (DatosUsuario u ){
        SQLiteDatabase db=getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(UID, u.getId());
        values.put(PASSWORD,u.getPassword());

        //insertar row
        db.insert(TABLE_NAME,null,values);
        db.close();
    }

    public DatosUsuario getData(String id ){
        SQLiteDatabase db=getReadableDatabase();

        Cursor cr =db.query(TABLE_NAME,new String[]  { UID , PASSWORD},UID+"=?",
                new String[] {id} , null ,null, null);
        DatosUsuario ud=null;
        if (cr.moveToFirst()){

            ud =new DatosUsuario(cr.getString(0) , cr.getString(1) );

        }
        return ud;
    }


    //Lee todos los datos de la tabla
    //public List< SurveyActivity> getAllData() {
       // List<SurveyActivity> udl = new ArrayList<SurveyActivity>();
       // String q = "select * from " + TABLE_NAME;
        //SQLiteDatabase db = getReadableDatabase();
        //Cursor cr = db.rawQuery(q, null);
       // if (cr.moveToFirst()) {
          //  do {
           //     SurveyActivity u = new SurveyActivity();
           //     u.setId(cr.getString(1));
           //     udl.add(u);
         //   } while (cr.moveToNext());


       // }
      //  return udl;
   // }



  // actualizando contraseña

    public int updatePassword (DatosUsuario u , String id ){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues val = new ContentValues();
        val.put(PASSWORD , u.getPassword());

        //Actualizando row
        return  db.update(TABLE_NAME, val , UID + "=?" , new String[] {id});
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
