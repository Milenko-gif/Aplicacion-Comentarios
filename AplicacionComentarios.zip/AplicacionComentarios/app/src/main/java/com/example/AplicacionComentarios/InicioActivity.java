package com.example.AplicacionComentarios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class InicioActivity extends AppCompatActivity {
    Ayudantebasedatos dbh;
    EditText uid , ped;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingreso);




    }

        public void validate (View v){
            uid=findViewById(R.id.uid);
            ped=findViewById(R.id.pass);
            dbh=new Ayudantebasedatos(this);

            DatosUsuario u=dbh.getData(uid.getText().toString());
            if (u!=null){

       // EditText uid=findViewById(R.id.userId);
         //   EditText pass=findViewById(R.id.pass);
         //   String uidstr=uid.getText().toString();
         //   String passtr=pass.getText().toString();
          // if (uidstr.equals("reham") && passtr.equals("123")){
               Intent in =new Intent();
              in.setClass(this, BienvenidaActivity.class);
              in.putExtra("id", uid.getText().toString());

            startActivity(in);
           }
           else{

                Toast.makeText(this, "ID de usuario o contraseña no válidos, inténtelo de nuevo!!" , Toast.LENGTH_LONG).show();
              //  uid.setText(null);
              //  pass.setText(null);
            }


        }



    public void callsign  (View v){
      Intent in = new Intent();
      in.setClass(this, IngresoActivity.class);
       startActivity(in);
    }





      /* facebook   */
    public void fb (View v){
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setData(Uri.parse("https://www.facebook.com"));
       startActivity(in);
    }


    /*  Twitter */

    public void tw (View v){
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setData(Uri.parse("https://www.twitter.com"));
        startActivity(in);
    }





    /*   Instagram   */

    public void inst (View v){
        Intent in = new Intent(Intent.ACTION_VIEW);
        in.setData(Uri.parse("https://www.instagram.com"));
        startActivity(in);
    }


}