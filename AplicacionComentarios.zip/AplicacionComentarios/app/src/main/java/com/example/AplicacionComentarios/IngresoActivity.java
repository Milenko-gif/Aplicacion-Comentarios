package com.example.AplicacionComentarios;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class IngresoActivity extends AppCompatActivity {
   // ed > usuario , ed1 > Contraseña
    Ayudantebasedatos dbh;
    EditText ed;
    SQLiteDatabase db;
    EditText ed1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscribirse);
        ed = findViewById(R.id.ed);
        dbh = new Ayudantebasedatos(this);
        // db = dbh.getWritableDatabase();
        //  db.execSQL("crear tabla si no existe empdetail (texto del nombre, texto de la contraseña) )");
        ed1 = findViewById(R.id.ed1);


        //   <11/1/2021 > EditText > user Este es un añadido para que al registrarte te aparezca un cartel de advertencia, que ya sabes debe ser pequeño.
        ed.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                ed.setError("El ID de usuario debe contener @");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //EditText > password Este es un añadido para que al registrarte te aparezca un cartel de advertencia, que ya sabes debe ser pequeño.

        ed1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                ed1.setError("La Contrtaseña debe tener mas de >6");
            }
        });

    }


    public void SaveData1(View v) {
        // Guardar nombre de usuario y contraseña

        String str = ed.getText().toString();
        String str1 = ed1.getText().toString();

        DatosUsuario ud = new DatosUsuario(str, str1);
        dbh.addData(ud);
        // db.execSQL("insert into empdetail values('"+str+"','"+str1+"')");
        Toast.makeText(this, "datos guardados", Toast.LENGTH_LONG).show();

    }



}