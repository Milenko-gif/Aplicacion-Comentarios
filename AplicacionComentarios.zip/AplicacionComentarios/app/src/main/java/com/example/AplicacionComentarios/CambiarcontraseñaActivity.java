package com.example.AplicacionComentarios;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class CambiarcontraseñaActivity extends AppCompatActivity {
    Ayudantebasedatos dbh;
    EditText ied , ped;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cambio_contrasena);
        ied=findViewById(R.id.ed);
        ped=findViewById(R.id.ed1);
        dbh=new Ayudantebasedatos(this);
    }


    public void changePassword (View v){
        String stri =ied.getText().toString();
        String strp=ped.getText().toString();
        DatosUsuario ud=new DatosUsuario(stri,strp);
        int i=dbh.updatePassword(ud,stri);
        Toast.makeText(this, "Contraseña Cambiada " +i , Toast.LENGTH_SHORT).show();


    }

}