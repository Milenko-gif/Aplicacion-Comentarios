package com.example.AplicacionComentarios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

public class EncuestaActivity extends AppCompatActivity {
    Ayudantebasedatos dbh;
    SQLiteDatabase db;
    private MQTTManager mqttManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encuesta);
        mqttManager = new MQTTManager(this);
    }

    public void subandext(View v){
        Intent in= new Intent();
        in.setClass(this, ServicioActivity.class);
        startActivity(in);

    }


    public void save(View v){
        // Recopilar datos de la encuesta
        JSONObject datosEncuesta = new JSONObject();
        try {
            datosEncuesta.put("usuarioId", obtenerIdUsuarioActual());
            datosEncuesta.put("calificacionHabitacion", obtenerCalificacionHabitacion());
        // Agregar más detalles de la encuesta
    } catch (JSONException e) {
        Log.e("Encuesta", "Error al crear el JSON", e);
    }

    // Publicar los datos de la encuesta a través de MQTT
    gestorMQTT.publicarEncuesta("habitacion", datosEncuesta.toString());

    // Navegar a la siguiente actividad
        Intent in= new Intent();
        in.setClass(this, AgradecimientosActivity.class);
        startActivity(in);

    }


}