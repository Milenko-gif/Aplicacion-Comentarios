package com.example.AplicacionComentarios;

import android.content.Context;
import android.util.Log;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class GestorMQTT {
    // Configuración del broker MQTT
    private static final String BROKER_URL = "tcp://broker.hivemq.com:1883"; 
    private static final String CLIENT_ID = "AplicacionComentarios" + System.currentTimeMillis();
    
    // Temas para diferentes tipos de encuestas
    private static final String TEMA_ENCUESTA_HABITACION = "hotel/encuestas/habitacion";
    private static final String TEMA_ENCUESTA_GIMNASIO = "hotel/encuestas/gimnasio";
    private static final String TEMA_ENCUESTA_COMIDA = "hotel/encuestas/comida";

    private MqttAndroidClient clienteMQTT;
    private Context contexto;

    public GestorMQTT(Context contexto) {
        this.contexto = contexto;
        inicializarClienteMQTT();
    }

    private void inicializarClienteMQTT() {
        clienteMQTT = new MqttAndroidClient(contexto, BROKER_URL, CLIENT_ID);
        
        clienteMQTT.setCallback(new MqttCallbackExtended() {
            @Override
            public void connectComplete(boolean reconectar, String servidorURI) {
                Log.d("MQTT", "Conexión completada");
            }

            @Override
            public void connectionLost(Throwable causa) {
                Log.d("MQTT", "Conexión perdida");
            }

            @Override
            public void messageArrived(String tema, MqttMessage mensaje) throws Exception {
                // Manejar los mensajes entrantes para los diferentes tipos de encuestas
                String contenido = new String(mensaje.getPayload());
                Log.d("MQTT", "Mensaje recibido: " + contenido + " en el tema: " + tema);
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Log.d("MQTT", "Entrega de mensaje completada");
            }
        });
    }

    public void conectar() {
        MqttConnectOptions opcionesConexion = new MqttConnectOptions();
        opcionesConexion.setAutomaticReconnect(true);
        opcionesConexion.setCleanSession(false);

        try {
            clienteMQTT.connect(opcionesConexion, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    DisconnectedBufferOptions opcionesBuffer = new DisconnectedBufferOptions();
                    opcionesBuffer.setBufferEnabled(true);
                    opcionesBuffer.setBufferSize(100);
                    opcionesBuffer.setPersistBuffer(false);
                    opcionesBuffer.setDeleteOldestMessages(false);
                    clienteMQTT.setBufferOpts(opcionesBuffer);

                    // Suscribirse a los temas de encuestas
                    suscribirseATemas();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable excepcion) {
                    Log.e("MQTT", "Error al conectar con el broker MQTT", excepcion);
                }
            });
        } catch (MqttException e) {
            Log.e("MQTT", "Error de conexión", e);
        }
    }

    private void suscribirseATemas() {
        try {
            clienteMQTT.subscribe(TEMA_ENCUESTA_HABITACION, 0);
            clienteMQTT.subscribe(TEMA_ENCUESTA_GIMNASIO, 0);
            clienteMQTT.subscribe(TEMA_ENCUESTA_COMIDA, 0);
        } catch (MqttException e) {
            Log.e("MQTT", "Error al suscribirse a los temas", e);
        }
    }

    public void publicarEncuesta(String tipoEncuesta, String datosEncuesta) {
        String tema;
        switch (tipoEncuesta) {
            case "habitacion":
                tema = TEMA_ENCUESTA_HABITACION;
                break;
            case "gimnasio":
                tema = TEMA_ENCUESTA_GIMNASIO;
                break;
            case "comida":
                tema = TEMA_ENCUESTA_COMIDA;
                break;
            default:
                return;
        }

        try {
            MqttMessage mensaje = new MqttMessage(datosEncuesta.getBytes());
            mensaje.setQos(0);
            clienteMQTT.publish(tema, mensaje);
        } catch (MqttException e) {
            Log.e("MQTT", "Error al publicar el mensaje", e);
        }
    }

    public void desconectar() {
        try {
            clienteMQTT.disconnect();
        } catch (MqttException e) {
            Log.e("MQTT", "Error al desconectar", e);
        }
    }
}
