package com.example.AplicacionComentarios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ServicioActivity extends AppCompatActivity {
    private MQTTManager mqttManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicio);

        // Iniciar MQTT
        mqttManager = new MQTTManager(this);
        mqttManager.connect();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mqttManager.disconnect();



    /* Cuarto */

    public void butroom(View v){
        Intent in= new Intent();
        in.setClass(this, EncuestaActivity.class);
        startActivity(in);

    }

    /* gym */

    public void butgy(View v){
        Intent in= new Intent();
        in.setClass(this, EncuestaGymActivity.class);
        startActivity(in);

    }

      /* Comida */

    public void butfood(View v){
        Intent in= new Intent();
        in.setClass(this, EncuestaComidaActivity.class);
        startActivity(in);

    }

}