package com.example.AplicacionComentarios;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class AgradecimientosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agradecer);
        RatingBar rt=findViewById(R.id.rt);
        TextView rate =findViewById(R.id.rate);
    final ImageView im =findViewById(R.id.im);

        rt.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                rate.setText(""+v);
                int value=(int)v;
                switch (value){
                    case 0:
                    case 1:
                    case 2:
                        im.setImageResource(R.drawable.sad);
                        break;
                    case 3:
                        im.setImageResource(R.drawable.bad);
                        break;
                    case 4:
                    case 5:
                        im.setImageResource(R.drawable.smile);

                }

            }
        });

    }




    public void giveRate(View v){
        Intent in= new Intent();
        in.setClass(this,MainActivity.class);
        startActivity(in);

    }


}